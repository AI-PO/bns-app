export * from "./RegisterDomainView";
